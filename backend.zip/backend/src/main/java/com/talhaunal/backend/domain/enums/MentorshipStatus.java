package com.talhaunal.backend.domain.enums;

public enum MentorshipStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}
