package com.talhaunal.backend.domain.enums;

public enum MentorStatus {
    HOLD,
    APPROVED,
    REJECTED
}
