package com.talhaunal.backend.domain.enums;

public enum PhaseStatus {
    NOT_STARTED,
    ACTIVE,
    COMPLETED
}
